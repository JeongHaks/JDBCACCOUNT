package com.kosta.jdbcdao.jjh;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class AccountImple implements AccountDAO{
	
	  private Connection conn = null;
	  private PreparedStatement pstmt = null;
	  private ResultSet rs = null;
	  int balance = 0;
	 
	  public Connection getConnection() {
	    Connection conn = null;
	    try {
	      Class.forName("oracle.jdbc.driver.OracleDriver");
	      String dburl = "jdbc:oracle:thin:@localhost:1521:xe";
	      conn = DriverManager.getConnection(dburl, "webdb", "1234");
	    } catch (ClassNotFoundException e) {
	      e.printStackTrace();
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }
	    return conn;
	  }

	//잔액 조회
	@Override
	public AccountVo getBalance() {
		conn = getConnection();
		String sql ="SELECT balance\r\n"
				+ "FROM account\r\n"
				+ "WHERE seq_id= (SELECT max(seq_id) FROM account)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
			      balance = rs.getInt("balance");
			      System.out.println("최종 잔액 : " + balance);
		      }
		    } catch (SQLException e) {
		      e.printStackTrace();
		    }

		return null;
	}

	//전체 조회
	@Override
	public List<AccountVo> getListAll() {
		List<AccountVo> list = new ArrayList<AccountVo>();
	    conn = getConnection();
	    String sql = " SELECT seq_id,"
	    		+ " deposit, "
	    		+ " withdraw,"
	    		+ " TO_CHAR(tr_date,'YYYY-MM-DD') tr_date ,"
	    		+ " balance\r\n"
	    		+ "FROM account";
	    try {
	      pstmt = conn.prepareStatement(sql);	      
	      rs = pstmt.executeQuery();	      	     
	      
	      while(rs.next()) {
	    	  int seq_id = rs.getInt(1);
	    	  int deposit = rs.getInt(2);
	    	  int withdraw = rs.getInt(3);
	    	  String tr_date = rs.getString(4);	    	  
		      int balance = rs.getInt(5);
		      AccountVo vo = new AccountVo( seq_id, deposit, withdraw, tr_date, balance);
	          list.add(vo);
	      }
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }
	    return list;
	}

	//검색 시작일~종료일
	@Override
	public List<AccountVo> getList(String searchStartDate,String searchEndDate) {
		List<AccountVo> list = new ArrayList<AccountVo>();
	    conn = getConnection();
	    String sql = " select seq_id, deposit, withdraw, to_char(tr_date,'YYYY-MM-DD'), balance\r\n"
	    		+ "from account \r\n"
	    		+ "where to_char(tr_date,'YYYYMMDD') BETWEEN ? AND ? ";
	    try {
	      pstmt = conn.prepareStatement(sql);
	      pstmt.setString(1, searchStartDate);
	      pstmt.setString(2, searchEndDate);
	      rs = pstmt.executeQuery();
	      
	      while(rs.next()) {
	    	  int seq_id = rs.getInt(1);
	    	  int deposit = rs.getInt(2);
	    	  int withdraw = rs.getInt(3);
	    	  String tr_date = rs.getString(4);	    	  
		      int balance = rs.getInt(5);
		      AccountVo vo = new AccountVo( seq_id, deposit, withdraw, tr_date, balance);
	          list.add(vo);
	      }
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }
	    return list;			
	}

	
	//입출금하기
	@Override
	public int insertTradeInfo(String tr, Long money) {				
		conn = getConnection();
        try {
		System.out.println("접속성공");
		if("입금".equals(tr)) { //입금			
			String sql = "INSERT INTO account(seq_id, deposit, withdraw, tr_date, balance)\r\n"
	        		+ "select ACCOUNT_SEQ_ID.nextval, ?, 0, sysdate, balance + ? \r\n"
	        		+ "from account\r\n"
	        		+ "where seq_id = (select max(seq_id) from account)";
				pstmt = conn.prepareStatement(sql);
	        	pstmt.setLong(1, money);
	        	pstmt.setLong(2, money);	        	
		}else { //출금						
			if(money > this.balance) {
				System.out.println("잔액이 부족합니다");
			}else {
			
			String sql = "INSERT INTO account(seq_id, deposit, withdraw, tr_date, balance)\r\n"
	        		+ "select ACCOUNT_SEQ_ID.nextval, 0, ?, sysdate, balance - ? \r\n"
	        		+ "from account\r\n"
	        		+ "where seq_id = (select max(seq_id) from account)";
				pstmt = conn.prepareStatement(sql);
	        	pstmt.setLong(1, money);
	        	pstmt.setLong(2, money);
			}
		}
        int count = pstmt.executeUpdate();
        
        //결과 처리 완료 횟수
        System.out.println(count + "건 처리");
        
        }catch(SQLException e) {
        	System.out.println("error : 드라이버 로딩 실패");
        }finally {
        	try {
        		if(pstmt != null) {pstmt.close();}
        		if(conn != null) {conn.close();}
        	}catch(SQLException e) {
        		System.out.println("error : " + e);
        	}
        }
        
		return 0;
	}

	//일자 조회 
	@Override
	public List<AccountVo> getList(String TradingDate) {		
		List<AccountVo> list = new ArrayList<AccountVo>();
	    conn = getConnection();
	    String sql = "select seq_id, deposit, withdraw, to_char(tr_date,'YYYY-MM-DD'), balance\r\n"
	    		+ "from account \r\n"
	    		+ "where to_char(tr_date,'YYYYMMDD') = ?";
	    try {
	      pstmt = conn.prepareStatement(sql);
	      pstmt.setString(1, TradingDate);	      
	      rs = pstmt.executeQuery();
	      
	      while(rs.next()) {
	    	  int seq_id = rs.getInt(1);
	    	  int deposit = rs.getInt(2);
	    	  int withdraw = rs.getInt(3);
	    	  String tr_date = rs.getString(4);	    	  
		      int balance = rs.getInt(5);
		      AccountVo vo = new AccountVo( seq_id, deposit, withdraw, tr_date, balance);
	          list.add(vo);
	      }
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }
	    return list;				
	}
}
