package com.kosta.jdbcdao.jjh;

public class AccountVo {
	
	private int seq_Id; //순서
	private int deposit;//입,출금
	private int withdraw;//출금
	private String tr_date; //거래일
	private int balance; //잔액
	
	
	public int getSeq_Id() {
		return seq_Id;
	}
	public void setSeq_Id(int seq_Id) {
		this.seq_Id = seq_Id;
	}
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	public String getTr_date() {
		return tr_date;
	}
	public void setTr_date(String tr_date) {
		this.tr_date = tr_date;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	/**
	 * @param seq_Id
	 * @param deposit
	 * @param withdraw
	 * @param tr_date
	 * @param balance
	 */
	public AccountVo(int seq_Id, int deposit, int withdraw, String tr_date, int balance) {
		this.seq_Id = seq_Id;
		this.deposit = deposit;
		this.withdraw = withdraw;
		this.tr_date = tr_date;
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "조회 [번호 =" + seq_Id + ", 입금액 =" + deposit + ", 출금액 =" + withdraw + ", 년월일 ="
				+ tr_date + ", 잔액 =" + balance + "]";
	}
}