package com.kosta.jdbcdao.jjh;

import java.util.List;

//연습용 -> 본용은 이름을 작성해서 제출
public interface AccountDAO {
  
	
	//잔액
	  public AccountVo getBalance();
  
	  //전체 조회
	  public List<AccountVo> getListAll();
	  
	  //기간별조회
	  public List<AccountVo> getList(String searchStartDate,String searchEndDate);
	  
	  //일자별조회
	  public List<AccountVo> getList(String TradingDate);
	  
	  //입,출금 추가
	  public int insertTradeInfo(String tr, Long money);
	  
  
}
