package com.kosta.jdbcdao.jjh;

import java.util.List;
import java.util.Scanner;

public class AccountApp {

	public static void main(String[] args) {

		boolean run = true;
		long number;		
		long money;//금액 입력
		long today; //거래일 조회
		//기간별 조회 
		long startday;
		long endday;
		
		AccountDAO dao = new AccountImple();
		Scanner sc = new Scanner(System.in);	
		
		
		while(run) {
			System.out.println(" ");
	    	System.out.println("---------------------------------------------------------------------------");
	    	System.out.println(" 1.예금 | 2.출금 | 3최종 잔액 조회 | 4.거래일 조회 | 5.기간별 조회 | 6.전체 조회 | 7.종료");
	    	System.out.println("---------------------------------------------------------------------------");
	    	System.out.println(" ");
	    	System.out.print("사용하실 번호를 입력해주세요 : " );
	    	//사용할 번호 받을 변수
	    	number = sc.nextLong();
	    	switch((int)number) {
	    		case 1: //입금
	    			System.out.print("입금하실 금액 : ");
	    	    	money = sc.nextLong();
	    			dao.insertTradeInfo("입금", money);
	    			break;
	    		case 2: // 출금
	    	    	System.out.print("출금하실 금액 : ");
	    	    	money = sc.nextLong(); 
	    	    	if(money < 0) {
	    	    		System.out.println("입금하실 수 없는 금액입니다.");
	    	    	}else if(money ==0) {
	    	    		System.out.println("입금해주세요.");
	    	    	}else {
	    	    		dao.insertTradeInfo("출금", money);
	    	    	}
	    			break;
	    		case 3://최종 잔액 조회
	    			dao.getBalance();
	    			break;
	    		case 4: //거래일 조회	    
	    			System.out.print("찾으실 날짜 입력 : (ex) 20220815");
	    	    	today = sc.nextLong();	    	    	
	    	    	String todays = String.valueOf(today);
	    			List<AccountVo> list1 = dao.getList(todays);
	    			for(AccountVo vo1 : list1) {
	    				System.out.println(vo1);
	    			}
	    			break;
	    		case 5://기간별 조회
	    			//기간별 조회	    			
	    			System.out.println("ex) 20220811 입력 후 20220812 입력!");
	    	    	startday = sc.nextLong();
	    	    	endday = sc.nextLong();
	    	    	System.out.print(startday + "부터 ");	    	    		    	    	
	    	    	System.out.println(endday + " 까지 ");
	    	    	String startdays = String.valueOf(startday);
	    	    	String enddays = String.valueOf(endday);
	    			List<AccountVo> list2 = dao.getList(startdays, enddays);
	    			for(AccountVo vo2 : list2) {
	    				System.out.println(vo2);
	    			}
	    			break;
	    		case 6: //전체 조회
	    			List<AccountVo> list = dao.getListAll(); //전체 조회 객체 선언
	    			for(AccountVo vo : list) {
	    				System.out.println(vo);
	    			}
	    			break;
	    		case 7:
	    			System.out.println("프로그램 종료");
	    			run = false;
	    			sc.close();
	    			
	    			break;
	    		default:
					System.out.println("다시 입력해주세요.");
					break;
				
	    	}
		}		
	}

}
